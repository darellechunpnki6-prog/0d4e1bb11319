// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Adapt data rate"); }
int main(){
  announce();
  return lionss_run_workload("LorawanAdr");
}
