# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(rk4_adaptive src/rk4_adaptive.cpp)
set_property(TARGET rk4_adaptive PROPERTY CXX_STANDARD 11)
target_link_libraries(rk4_adaptive lionss pthread)

add_executable(flac_md5 src/flac_md5.cpp)
set_property(TARGET flac_md5 PROPERTY CXX_STANDARD 11)
target_link_libraries(flac_md5 lionss pthread)

add_executable(peak-macs2 src/peak-macs2.cpp)
set_property(TARGET peak-macs2 PROPERTY CXX_STANDARD 11)
target_link_libraries(peak-macs2 lionss pthread)

add_executable(cassandra_repair src/cassandra_repair.cpp)
set_property(TARGET cassandra_repair PROPERTY CXX_STANDARD 11)
target_link_libraries(cassandra_repair lionss pthread)

add_executable(zfs_scrub src/zfs_scrub.cpp)
set_property(TARGET zfs_scrub PROPERTY CXX_STANDARD 11)
target_link_libraries(zfs_scrub lionss pthread)

add_executable(btree-vacuum src/btree-vacuum.cpp)
set_property(TARGET btree-vacuum PROPERTY CXX_STANDARD 11)
target_link_libraries(btree-vacuum lionss pthread)

add_executable(icc_profile src/icc_profile.cpp)
set_property(TARGET icc_profile PROPERTY CXX_STANDARD 11)
target_link_libraries(icc_profile lionss pthread)

add_executable(copper-moth src/copper-moth.cpp)
set_property(TARGET copper-moth PROPERTY CXX_STANDARD 11)
target_link_libraries(copper-moth lionss pthread)

add_executable(LorawanAdr src/LorawanAdr.cpp)
set_property(TARGET LorawanAdr PROPERTY CXX_STANDARD 11)
target_link_libraries(LorawanAdr lionss pthread)

add_executable(smartctl_long src/smartctl_long.cpp)
set_property(TARGET smartctl_long PROPERTY CXX_STANDARD 11)
target_link_libraries(smartctl_long lionss pthread)

add_executable(nvmeTrim src/nvmeTrim.cpp)
set_property(TARGET nvmeTrim PROPERTY CXX_STANDARD 11)
target_link_libraries(nvmeTrim lionss pthread)

add_executable(pitchShift2x src/pitchShift2x.cpp)
set_property(TARGET pitchShift2x PROPERTY CXX_STANDARD 11)
target_link_libraries(pitchShift2x lionss pthread)

add_executable(tiderun src/tiderun.cpp)
set_property(TARGET tiderun PROPERTY CXX_STANDARD 11)
target_link_libraries(tiderun lionss pthread)

add_executable(thread-border src/thread-border.cpp)
set_property(TARGET thread-border PROPERTY CXX_STANDARD 11)
target_link_libraries(thread-border lionss pthread)

add_executable(LbfgsTwoloop src/LbfgsTwoloop.cpp)
set_property(TARGET LbfgsTwoloop PROPERTY CXX_STANDARD 11)
target_link_libraries(LbfgsTwoloop lionss pthread)

add_executable(biquad-lp src/biquad-lp.cpp)
set_property(TARGET biquad-lp PROPERTY CXX_STANDARD 11)
target_link_libraries(biquad-lp lionss pthread)

add_executable(stackmap_gc src/stackmap_gc.cpp)
set_property(TARGET stackmap_gc PROPERTY CXX_STANDARD 11)
target_link_libraries(stackmap_gc lionss pthread)

add_executable(duckdbprobe src/duckdbprobe.cpp)
set_property(TARGET duckdbprobe PROPERTY CXX_STANDARD 11)
target_link_libraries(duckdbprobe lionss pthread)

add_executable(Tanager src/Tanager.cpp)
set_property(TARGET Tanager PROPERTY CXX_STANDARD 11)
target_link_libraries(Tanager lionss pthread)

add_executable(borg_compact src/borg_compact.cpp)
set_property(TARGET borg_compact PROPERTY CXX_STANDARD 11)
target_link_libraries(borg_compact lionss pthread)

add_executable(windowFrame src/windowFrame.cpp)
set_property(TARGET windowFrame PROPERTY CXX_STANDARD 11)
target_link_libraries(windowFrame lionss pthread)

add_executable(ssaDestruct src/ssaDestruct.cpp)
set_property(TARGET ssaDestruct PROPERTY CXX_STANDARD 11)
target_link_libraries(ssaDestruct lionss pthread)

add_executable(xxhash3 src/xxhash3.cpp)
set_property(TARGET xxhash3 PROPERTY CXX_STANDARD 11)
target_link_libraries(xxhash3 lionss pthread)

add_executable(tickresample src/tickresample.cpp)
set_property(TARGET tickresample PROPERTY CXX_STANDARD 11)
target_link_libraries(tickresample lionss pthread)

add_executable(epoll_edge src/epoll_edge.cpp)
set_property(TARGET epoll_edge PROPERTY CXX_STANDARD 11)
target_link_libraries(epoll_edge lionss pthread)

add_executable(HaskellStrictness src/HaskellStrictness.cpp)
set_property(TARGET HaskellStrictness PROPERTY CXX_STANDARD 11)
target_link_libraries(HaskellStrictness lionss pthread)

add_executable(assetBundleV3 src/assetBundleV3.cpp)
set_property(TARGET assetBundleV3 PROPERTY CXX_STANDARD 11)
target_link_libraries(assetBundleV3 lionss pthread)

add_executable(restic_prune src/restic_prune.cpp)
set_property(TARGET restic_prune PROPERTY CXX_STANDARD 11)
target_link_libraries(restic_prune lionss pthread)

add_executable(squall src/squall.cpp)
set_property(TARGET squall PROPERTY CXX_STANDARD 11)
target_link_libraries(squall lionss pthread)

add_executable(TurnRelay src/TurnRelay.cpp)
set_property(TARGET TurnRelay PROPERTY CXX_STANDARD 11)
target_link_libraries(TurnRelay lionss pthread)

