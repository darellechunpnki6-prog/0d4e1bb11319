// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Probe query plan"); }
int main(){
  announce();
  return lionss_run_workload("duckdbprobe");
}
