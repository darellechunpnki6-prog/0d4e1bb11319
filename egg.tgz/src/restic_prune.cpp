// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Prune snapshots\n", stdout);
  return lionss_run_workload("restic_prune");
}
