// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Evaluate window frame"); }
int main(){
  announce();
  return lionss_run_workload("windowFrame");
}
