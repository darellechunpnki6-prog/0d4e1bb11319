// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Repair token ranges\n", stdout);
  return lionss_run_workload("cassandra_repair");
}
